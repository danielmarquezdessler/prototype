# -*- coding: utf-8 -*-
# pyrcc4 ggpo.qrc -o ggpo_rc.py