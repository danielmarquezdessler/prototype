# -*- coding: utf-8 -*-
from collections import OrderedDict


# noinspection PyClassHasNoInit
class CLI:
    ARG_TYPE, HELPSTRING = range(2)
    NO_ARG, REQUIRED_ARG, OPTIONAL_ARG = range(3)

    commands = OrderedDict([
        ("/away", [NO_ARG, "away from keyboard"]),
        ("/back", [NO_ARG, "become available to play"]),
        ("/accept", [OPTIONAL_ARG, "accept incoming challenge"]),
        ("/decline", [OPTIONAL_ARG, "decline incoming challenge"]),
        ("/incoming", [NO_ARG, "list all incoming challenges"]),
        ("/challenge", [REQUIRED_ARG, "challenge player"]),
        ("/cancel", [NO_ARG, "cancel outgoing challenge"]),
        ("/watch", [REQUIRED_ARG, "spectate a game"]),
        ("/replay", [REQUIRED_ARG, "replay a saved game"]),
        ("/direct", [REQUIRED_ARG, "play a direct match"]),
        ("/play", [NO_ARG, "play game alone"]),
        ("/ignore", [REQUIRED_ARG, "ignore a player"]),
        ("/unignore", [REQUIRED_ARG, "unignore a player"]),
        ("/motd", [NO_ARG, "clear screen and show message of the day"]),
        ("/help", [NO_ARG, "display help menu"])
    ])

    @classmethod
    def helptext(cls):
        def argtext(v):
            return v[cls.ARG_TYPE] == cls.NO_ARG and " " or " [name]"

        return "Available commands:\n" + \
               "\n".join(["{}{}  -   {}".format(k, argtext(v), v[cls.HELPSTRING])
                          for k, v in cls.commands.items()])

    # need cleaner api for AFK, passing an action is a hack for now
    @classmethod
    def process(cls, controller, afkSetChecked, line):
        def cliaccept(name=None):
            if not name:
                for challenger in controller.challengers:
                    name = challenger
            if name:
                controller.sendAcceptChallenge(name)

        def cliaway():
            controller.sigStatusMessage.emit("Mudando para OCUPADO")
            afkSetChecked(True)
            controller.sendToggleAFK(1)

        def cliback():
            controller.sigStatusMessage.emit("{} pronto para jogar".format(controller.username))
            afkSetChecked(False)
            controller.sendToggleAFK(0)

        def clicancel():
            if controller.challenged:
                controller.sigStatusMessage.emit("Luta cancelada {}".format(controller.challenged))
                controller.sendCancelChallenge(controller.challenged)
            else:
                controller.sigStatusMessage.emit("Nenhuma luta para cancelada")

        def clichallenge(name):
            if name in controller.available:
                controller.sigStatusMessage.emit("Desafiando {}".format(name))
                controller.sendChallenge(name)
            else:
                controller.sigStatusMessage.emit("{} nao esta disponivel".format(name))

        def clidecline(name=None):
            if name:
                controller.sigStatusMessage.emit("Jogo de {} cancelado".format(name))
                controller.sendDeclineChallenge(name)
            else:
                for challenger in controller.challengers:
                    controller.sigStatusMessage.emit("Cancelado jogo de {}".format(challenger))
                    controller.sendDeclineChallenge(challenger)

        def cligeoip():
            names = controller.available.keys() + controller.awayfromkb.keys() + controller.playing.keys()
            names.sort(key=str.lower)
            for n in names:
                p = controller.players[n]
                country = ''
                if p.country:
                    # getting the dreadful error
                    # UnicodeEncodeError: 'ascii' codec can't encode character
                    #country = p.country.decode('utf-8', 'ignore')
                    country = p.country
                city = ''
                if p.city:
                    #city = p.city.decode('utf-8', 'ignore')
                    city = p.city
                msg = u"{} {} {} {}".format(n, p.ip, country, city)
                controller.sigStatusMessage.emit(msg)

        def clihelp():
            controller.sigStatusMessage.emit(cls.helptext())

        def cliignore(name):
            if name in controller.ignored:
                controller.sigStatusMessage.emit("{} atualmente na lista de bloqueados".format(name))
            else:
                controller.addIgnore(name)

        def climotd():
            controller.sendMOTDRequest()

        def cliunignore(name):
            if name in controller.ignored:
                controller.removeIgnore(name)
            else:
                controller.sigStatusMessage.emit("{} fora da lista de bloqueados".format(name))

        def cliwatch(name):
            if name in controller.playing.keys():
                controller.sendSpectateRequest(name)
            else:
                controller.sigStatusMessage.emit("{} nao esta jogando".format(name))

        def clireplay(name):
            if '@' in name:
                channel = name.split('@')[1]
                replay_id = name.split('@')[0]
            else:
                channel = controller.channel
                replay_id = name
            quark = "quark:stream,"+channel+","+replay_id+",7001"
            controller.runFBA(quark)
            controller.sigStatusMessage.emit("Replaying game-id {}@{}".format(replay_id, channel))

        def clidirect(name):
            try:
                p = controller.players[name]
                if (str(controller.username) < str(name)):
                    side=0
                    port1=6000
                    port2=6001
                else:
                    side=1
                    port1=6001
                    port2=6000
                quark = "quark:direct,"+str(controller.channel)+","+str(port1)+","+str(p.ip)+","+str(port2)+","+str(side)
                controller.runFBA(quark)
                controller.sigStatusMessage.emit("Direct match with {} @ {}".format(name, controller.channel))
                afkSetChecked(True)
                controller.sendToggleAFK(1)
            except KeyError:
                controller.sigStatusMessage.emit("Can't find {} @ {}".format(name, controller.channel))

        def cliplay():
            controller.runFBA(controller.channel)
            controller.sigStatusMessage.emit("Launching {}".format(controller.channel))

        if line.startswith("/geo"):
            return cligeoip()
        words = line.split(None, 1)
        command = words[0]
        if command in cls.commands:
            cmd = cls.commands[command]
            callback = locals()['cli' + command[1:]]
            if cmd[cls.ARG_TYPE] == cls.NO_ARG:
                callback()
            elif cmd[cls.ARG_TYPE] == cls.REQUIRED_ARG:
                if len(words) != 2:
                    clihelp()
                else:
                    callback(words[1])
            elif cmd[cls.ARG_TYPE] == cls.OPTIONAL_ARG:
                if len(words) >= 2:
                    callback(words[1])
                else:
                    callback()
        else:
            clihelp()

