import webbrowser
from PyQt4 import QtGui, QtWebKit, QtCore

class UserLabel(QtGui.QLabel):
    def add_url(self, url):
        self.url = url
    def mouseReleaseEvent(self, event):
        webbrowser.open(self.url, new=0, autoraise=True)

class CustomWebView(QtWebKit.QWebView):
    def createWindow(self, *args, **kwargs):
        link = self.page().mainFrame().hitTestContent(self.position).linkUrl().toString()
        webbrowser.open(link, new=0, autoraise=True)
        return QtWebKit.QWebView.createWindow(self, *args, **kwargs)
    def mousePressEvent(self, event):
        self.position = event.pos()
        return QtWebKit.QWebView.mousePressEvent(self, event)
    def contextMenuEvent(self, event):
        event.ignore()
