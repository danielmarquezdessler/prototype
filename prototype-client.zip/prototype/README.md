fightcade client
================

This is a cross platform (Linux,  MacOSX, Windows) GUI client for
[FightCade](http://www.fightcade.com) written in python using the
[pyqt4](http://www.riverbankcomputing.com/software/pyqt/download) framework.

&copy;2014 papasi, pof GPL v2 License
