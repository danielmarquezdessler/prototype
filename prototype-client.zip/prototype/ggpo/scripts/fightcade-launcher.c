#include <stdlib.h>
int main() {
	system("/Applications/FightCade.app/Contents/MacOS/fightcade");
}
